int buttonPin = 2;
int ledPin = 8;

bool ledState = false;

void setup()
{
    pinMode(buttonPin, INPUT);
    pinMode(ledPin, OUTPUT);
}

void loop()
{
    int buttonState = digitalRead(buttonPin);

    if(buttonState == 1)
    {
        ledState = !ledState;

        digitalWrite(ledPin, ledState);

        delay(500);
    }
}